package MyPractice;

public class UnaryOperatorExample2 {

	public static void main(String[] args) {
		
		int a=-18;
		System.out.println(~a);//
		

	}

}
