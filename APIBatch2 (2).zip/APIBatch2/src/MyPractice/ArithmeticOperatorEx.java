package MyPractice;

public class ArithmeticOperatorEx {

	public static void main(String[] args) {
		
		int a=400;
		int b=18;
		int c=40;
		
//		int d=a+b+c;
//		int e=c-b;
//		int f=a*b*c;
		
		int x=a%b;
		System.out.println(x);
		
		
		

	}

}
