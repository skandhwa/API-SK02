package AuthenticationinRestAssured;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class BearerTokenAuthentication {

	public static void main(String[] args) {
		
		String token="Bearer 07824646f33266c8831320fbae029d939ba21bf5fb615fb110fd3b425ac076c3";
		
		RestAssured.baseURI="https://gorest.co.in";
		JSONObject payload=new JSONObject();
		payload.put("name", "Manish");
		payload.put("gender", "Male");
		payload.put("email", "Manishrdftger@gmail.com");
		payload.put("status", "Active");
		
		
	String Response=	given().log().all()
		.headers("Authorization",token)
		.headers("Content-Type","application/json")
		.body(payload.toJSONString()).when().post("public/v2/users")
		.then().assertThat().statusCode(201).
		extract().response().asString();
	
	System.out.println(Response);
		
		
		

	}

}
