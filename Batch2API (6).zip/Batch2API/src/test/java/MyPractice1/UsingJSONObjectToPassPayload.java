package MyPractice1;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;

public class UsingJSONObjectToPassPayload {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="https://reqres.in";
		
		JSONObject payload=new JSONObject();
		payload.put("name", "Tim");
		payload.put("leader", "QAManager");
		
		
		
String Response=given().log().all().relaxedHTTPSValidation()
				
				.header("Content-Type","application/json")
			.header("Connection","keep-alive")
			.body(payload)
			
			.when().post("api/users")
			
			.then().
			log().all().assertThat().statusCode(201).
			
			header("Server",equalTo("cloudflare"))


			.extract().response().asString();
		
		System.out.println(Response);
		
		
		
		
		

	}

}
