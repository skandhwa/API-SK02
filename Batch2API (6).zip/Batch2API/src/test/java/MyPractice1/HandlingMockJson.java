package MyPractice1;

import org.testng.Assert;

import Payload.payloadData;
import io.restassured.path.json.JsonPath;

public class HandlingMockJson {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(payloadData.MockJsonData());
		
		int sum=0;
		
		////Print No of courses returned by API
		
	int x=	js.getInt("courses.size()");
	System.out.println("The  No of courses returned by API is  "+x);
	
	///Print Purchase Amount
	
	int amount=js.getInt("dashboard.purchaseAmount");
	System.out.println("The total Purchase amount is  "+amount);
	
	//Print Title of the first course
	
	String TitleFirstCourse=  js.getString("courses[0].title");
	System.out.println("The title of first course is  "+TitleFirstCourse);

	
	///Print All course titles and their respective Prices
	
	System.out.println("The title and respective prices are");
	
	for(int i=0;i<x;i++)//i=0,0<3//i=1,1<3//i=2,2<3//i=3,3<3
	{
	String CoursesValues=js.getString("courses["+i+"].title")	;
	int Prices=js.getInt("	courses["+i+"].price");
	
	
	System.out.print(CoursesValues+"  ");
	System.out.println(Prices);
	}
	
	
	
	/////Verify if Sum of all Course prices matches with Purchase Amount

System.out.println("The title and respective prices are");
	
	for(int j=0;j<x;j++)//j=0,0<3//j=1,1<3//j=2,2<3/
	{
	int PricesN=js.getInt("courses["+j+"].price")	;
	int CopiesN=js.getInt("	courses["+j+"].copies");
	int amount1=PricesN*CopiesN;
	
	sum=sum+amount1;
	
	
	
	
	
	
	
	
	
	
	}
	System.out.println("The total sum is  "+sum);
	
	Assert.assertEquals(sum, amount);
	System.out.println("Both the amount are matched and test case is passed");
	
	
		
		

	}

}
