package MyPractice1;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class HandlingStaticPayload {

	public static void main(String[] args) throws IOException {
		
		RestAssured.baseURI="https://reqres.in";
		String Response=	given().log().all().relaxedHTTPSValidation().headers("Content-Type","application/json")
			.body(new String(Files.readAllBytes(Paths.get("D:\\AddName.json")))).when().post("api/users")
			.then().assertThat().statusCode(201).log().all().extract().response().asString();
		
		System.out.println(Response);
		
		
		
		

	}

}
