package MyPractice1;

import static io.restassured.RestAssured.given;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Payload.payloadData;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class UsingDPtoPassMultipleTestData {
	
	@DataProvider(name="booksdata")
	
	public Object[][] getData()
	{
		return new Object[][]
				{
			
			{"yurt","9854"},
			{"iurt","9854"},
			{"htre","8532"}
			};
		
		
	}
	
	
	@Test(dataProvider="booksdata")
	public void AddMultipleBooks(String isbn,String aisle)
	{
		RestAssured.baseURI="http://216.10.245.166";
		String Response=	given().log().all().header("Content-Type","application/json")
				.body(payloadData.AddBookDetails(isbn,aisle))
				
				.when().post("/Library/Addbook.php")
				
				.then().log().all().assertThat().statusCode(200).extract().response()
				.asString();
			
			
			System.out.println(Response);
			
			JsonPath js=new JsonPath(Response);
			String FetchedID=js.getString("ID");
			System.out.println(FetchedID);
	}
	
	
	
	
	

}
