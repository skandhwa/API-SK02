package MyPractice1;

import io.restassured.RestAssured;

import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;

import Payload.CookieData;

public class HandlingCookiesinRestAssured {

	public static void main(String[] args) {
		
		 RestAssured.baseURI="https://postman-echo.com";
		 
	String Response=	 given().log().all().cookies(CookieData.SetCookieData())
		 .when().post("cookies/set").then().extract().response().asString();
	
	
	System.out.println(Response);
		 

	}

}
