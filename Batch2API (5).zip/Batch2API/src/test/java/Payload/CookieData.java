package Payload;

import java.util.LinkedHashMap;
import java.util.Map;

public class CookieData {
	
	public static Map SetCookieData()
	{
		Map<String,Object>mp=new LinkedHashMap<String,Object>();
		mp.put("name","saurabh");
		mp.put("password", "test1234");
		return mp;
	}
	

}
