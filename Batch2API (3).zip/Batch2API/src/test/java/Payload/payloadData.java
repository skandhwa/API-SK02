package Payload;

public class payloadData {
	
	public static String AddName(String name,String Jobrole)
	{
		String payloadData="{\r\n"
				+ "    \"name\": \""+name+"\",\r\n"
				+ "    \"job\": \""+Jobrole+"\"\r\n"
				+ "}";
		
		return payloadData;
	}
	
	public static String AddBookDetails(String isbn,String aisle)
	{
		String bookData="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with Java\",\r\n"
				+ "\"isbn\":\""+isbn+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}";
		
		return bookData;
	}
	
	
	
	

}
