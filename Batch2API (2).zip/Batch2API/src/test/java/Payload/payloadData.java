package Payload;

public class payloadData {
	
	public static String AddName()
	{
		String payloadData="{\r\n"
				+ "    \"name\": \"Tom\",\r\n"
				+ "    \"job\": \"Manager\"\r\n"
				+ "}";
		
		return payloadData;
	}
	
	
	

}
