package SerializationAndDeserialization;

import static io.restassured.RestAssured.*;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class CreateNewUser {
	
	@Test
	public void createUser()
	{
		JSONObject payload=new JSONObject();
		payload.put("name", "morpheus");
		payload.put("job", "manager");
		
		RestAssured.baseURI="https://reqres.in";
		///
		
	Response response=	given().log().all().body(payload.toJSONString()).header("Content-Type","application/json").
		when().post("api/users").then().extract().response();
	
	System.out.println("The JSON Respoinse is");
	System.out.println();
	System.out.println(response);
	
	System.out.println();
	      
	  ResponseBody obj=      response.getBody();
	  
	  JsonProcessingEx res=obj.as(JsonProcessingEx.class);
	  
	String name=  res.name;
	String job=  res.job;
	
	System.out.println(name);
	System.out.println(job);
	
	Assert.assertEquals(name,"morpheus","Checking the name" );
	Assert.assertEquals(job,"manager","Checking the job" );
	
	System.out.println("My Test case passed");
	
	
	  
		
	 
		
		
	}
	
	
	

}
