package SpecBuilder;

import org.testng.Assert;
import org.testng.annotations.Test;

import Payload.payloadData;

import static io.restassured.RestAssured.*;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class MySpecBuilder1 {
	
	@Test
	public void mytest()
	{
		
		
	RequestSpecification req=new RequestSpecBuilder().setBaseUri("https://reqres.in/")
		.setContentType(ContentType.JSON).build();
		
		
		RequestSpecification res=	given().log().all().
				spec(req).body(payloadData.AddName("Tom","QA Manager"));
		
		
		ResponseSpecification respec= new ResponseSpecBuilder()
				.expectStatusCode(201).expectContentType(ContentType.JSON)
				.expectHeader("Server","cloudflare").build();
		
		
	Response response=	res.when().post("api/users").then().log().all().spec(respec).extract()
		.response();
	
	String ActualResponse=response.asString();
	
	System.out.println(ActualResponse);
	
	JsonPath js=new JsonPath(ActualResponse);
	
	js.getString("name");
	
	String ActualName="Tom";
	
	Assert.assertEquals(ActualName, "Tom");
	
	
	

		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	

}
