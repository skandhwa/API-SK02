package SpecBuilder;

import org.testng.annotations.Test;
import Payload.payloadData;
import ReUsableMethods.RequestResponseSpecification;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import static io.restassured.RestAssured.*;


public class MySpecBuilder3 {
	
	@Test
	
	public void GetListOfUser()
	{
		
	RequestSpecification res=	given().log().all().spec(RequestResponseSpecification.addRequest());
	
	String response=res.when().get("api/users/3").then().spec(RequestResponseSpecification.validateRequest(200))
			.extract().response().asString();
	
	System.out.println(response);
	
	
		
		
	}
	
	
	

}
