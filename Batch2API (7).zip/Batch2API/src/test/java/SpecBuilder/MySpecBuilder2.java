package SpecBuilder;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import Payload.payloadData;
import ReUsableMethods.RequestResponseSpecification;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class MySpecBuilder2 {
	
	@Test
	public void validateRequest()
	{
		
		RequestSpecification res=	given().log().all().spec(RequestResponseSpecification.addRequest())
				;
		
		Response response=	res.when().get("api/users/2").then().log().all().
				spec(RequestResponseSpecification.validateRequest(200)).extract()
				.response();
		
		String responsenew=response.asString();
		
		System.out.println(responsenew);
		
		
		
	}
	
	
	

}
