package ReUsableMethods;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class RequestResponseSpecification {
	
	public static RequestSpecification addRequest()
	{
		RequestSpecification req=new RequestSpecBuilder().setBaseUri("https://reqres.in/")
				.setContentType(ContentType.JSON).build();
		
		return req;
	}
	
	public static ResponseSpecification validateRequest(int statuscodeval)
	{
		ResponseSpecification respec= new ResponseSpecBuilder()
				.expectStatusCode(statuscodeval).expectContentType(ContentType.JSON)
				.expectHeader("Server","cloudflare").build();
		
		return respec;
	}
	
	

}
