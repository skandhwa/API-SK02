package MISCTopics;

import io.restassured.RestAssured;
import io.restassured.filter.session.SessionFilter;
import static io.restassured.RestAssured.*;

public class UsingsessionFilter {

	public static void main(String[] args) {
		
		SessionFilter ssr=new SessionFilter();
		
		
		RestAssured.baseURI="https://httpbin.org/post";
	String Response=	given().log().all().filter(ssr).when().post()
		.then().extract().response().asString();
	System.out.println(Response);
	
	
	
	String Response2=given().log().all().filter(ssr).when().post()
	.then().extract().response().asString();
System.out.println(Response2);
	
	
		
		
		

	}

}
