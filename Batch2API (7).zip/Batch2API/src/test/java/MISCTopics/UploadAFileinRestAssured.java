package MISCTopics;

import java.io.File;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

public class UploadAFileinRestAssured {

	public static void main(String[] args) {
		
		String str="abcd";
		RestAssured.baseURI="https://httpbin.org/post";
		File f=new File("D:\\03rdOctoberFileNew\\test1567.txt");
		File f1=new File("C:\\Users\\saura\\OneDrive\\Pictures\\Test1234.jpeg");
	String path=	f.getPath();
	System.out.println(path);
	
String Response=	given().relaxedHTTPSValidation().
log().all().header("Content-Type","multipart/form-data")
	.multiPart("file",f)
	.multiPart("file",f1)
	.multiPart("text",str)
	.when().post().then().assertThat().statusCode(200).
	log().all().extract().response().asString();

System.out.println(Response);

JsonPath js=new JsonPath(Response);
String FileData=js.getString("files.file");
System.out.println(FileData);
	
	
	
	
		
		
		

	}

}
