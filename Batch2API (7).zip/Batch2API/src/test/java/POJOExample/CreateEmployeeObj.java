package POJOExample;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CreateEmployeeObj {
	
	@Test
	public void createUser() throws JsonProcessingException
	{
		EmployeeNew emp=new EmployeeNew();
		emp.setName("Harry");
		emp.setJob("QA lead");
		
		ObjectMapper obj=new ObjectMapper();
		
	String employeeJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
		System.out.println(employeeJSON);
		
		
	}
	
	

}
