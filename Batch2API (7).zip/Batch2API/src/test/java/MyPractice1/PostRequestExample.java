package MyPractice1;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;

import Payload.payloadData;

public class PostRequestExample {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		String ActualName="Harry";
		String jobrole="Analyst";
		
		String TodayDate="2024-05-09";
		
		String Response=given().log().all().relaxedHTTPSValidation()
			
			.header("Content-Type","application/json")
		.header("Connection","keep-alive")
		.body(payloadData.AddName(ActualName,jobrole))
		
		.when().post("api/users")
		
		.then().log().all().assertThat().statusCode(201).
		body("name",equalTo("Harry")).
		header("Server",equalTo("cloudflare"))
		.extract().response().asString();
	
	System.out.println(Response);
	
	
	
	
	JsonPath js=new JsonPath(Response);
	
	String Fetchedname=js.getString("name");
	
	Assert.assertEquals(Fetchedname, ActualName);
	
	System.out.println("Test Case passed");
	
	
	String CreatedAt=js.getString("createdAt");
	
	String[] date=	CreatedAt.split("T");
	
	System.out.println(date[0]);
	
	if(date[0].equals(TodayDate))
	{
		System.out.println("Date is correct");
	}
	else
	{
		System.out.println("Incorrect Date");
	}
	
	
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
