package MyPractice1;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.*;

import org.testng.Assert;



public class MySecondPractice {

	public static void main(String[] args) {
		
		String ActFirstName="Michael";
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=given().log().all().queryParam("page","2").header("Connection","keep-alive")
		.when().get("api/users")
		.then().log().all().statusCode(200).extract().response().asString();

	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	
String Fname=	js.getString("data[0].first_name");

System.out.println(Fname);

Assert.assertEquals(Fname,ActFirstName);


System.out.println("My Test Case passed");


	
	
	}

}
