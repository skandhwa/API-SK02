package MyPractice1;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import Payload.payloadData;
import io.restassured.RestAssured;

public class UsingMaptoPassPayload {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		
		mp.put("name","Saurabh");
		mp.put("EmpID",1234);
		mp.put("IsMarried",true);
		mp.put("StateCode",'A');
		
		
Map<String,Object> mp2=new LinkedHashMap<String,Object>();
		
		mp2.put("name","Harish");
		mp2.put("EmpID",6789);
		mp2.put("IsMarried",false);
		mp2.put("StateCode",'B');
		
Map<String,Object> mp3=new LinkedHashMap<String,Object>();
		
		mp3.put("name","Girish");
		mp3.put("EmpID",9087);
		mp3.put("IsMarried",true);
		mp3.put("StateCode",'C');
		
		
	
	List<Map<String,Object>> li=new ArrayList();
	li.add(mp);
	li.add(mp2);
	li.add(mp3);
	
	
		
		
		
		String Response=given().log().all().relaxedHTTPSValidation()
				
				.header("Content-Type","application/json")
			.header("Connection","keep-alive")
			.body(li)
			
			.when().post("api/users")
			
			.then().
			log().all().assertThat().statusCode(201).
			
			header("Server",equalTo("cloudflare"))


			.extract().response().asString();
		
		System.out.println(Response);
		

	}

}
