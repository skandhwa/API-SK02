package MyPractice1;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.*;

import org.testng.Assert;

import Payload.payloadData;;

public class AddingBooksLibraryAPI {

	public static void main(String[] args) {
		
		RestAssured.baseURI="http://216.10.245.166";
		
		String ISBN="ZERT";
		String aisle="8965";
		
		String ExpectedID=ISBN+aisle;
		
		
	String Response=	given().log().all().header("Content-Type","application/json")
		.body(payloadData.AddBookDetails(ISBN,aisle))
		
		.when().post("/Library/Addbook.php")
		
		.then().log().all().assertThat().statusCode(200).extract().response()
		.asString();
	
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	String FetchedID=js.getString("ID");
	System.out.println(FetchedID);
	
	Assert.assertEquals(FetchedID, ExpectedID);
	System.out.println("Test Case Passed");
	
	
	
		

	}

}
