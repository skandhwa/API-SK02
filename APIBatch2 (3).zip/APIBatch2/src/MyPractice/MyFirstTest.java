package MyPractice;

import java.util.Scanner;

public class MyFirstTest {
	
	
	public static void main(String[] args) {
		
		System.out.println("Hello this is java");
		System.out.println("Hello this is java");
		
		
		
		
		

	}

}
