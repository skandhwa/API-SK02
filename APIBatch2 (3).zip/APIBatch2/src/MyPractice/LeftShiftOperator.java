package MyPractice;

public class LeftShiftOperator {

	public static void main(String[] args) {
		
		
		//System.out.println(10<<3);
		
		//10*2pow3
		
		//System.out.println(12<<4);//12*2pow4=12*16=192
		
		//System.out.println(14<<3);//14*2pow3=14*8=112
		
		System.out.println(120>>3);  ///  120/2pow3=120/8
		
		System.out.println(98>>4);///98/2pow4=98/16
		
	}

}
