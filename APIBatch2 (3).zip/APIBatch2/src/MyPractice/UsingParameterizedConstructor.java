package MyPractice;

class D
{
	int rollno;
	String name;
	float salary;
	char status;
	
	D(int r,String n,char s)
	{
		rollno=r;
		name=n;
		status=s;		
	}
	
	D(int r1,String n1,float s1)
	{
		rollno=r1;
		name=n1;
		salary=s1;
		
		
	}
	
	void display()
	{
		System.out.println(rollno+"  "+name+"  "+salary+"  "+status);
	}

}



public class UsingParameterizedConstructor {

	public static void main(String[] args) {
		
		D obj=new D(1234,"Tom",'A');
		obj.display();
		
		D obj1=new D(4567,"Mark",23432432f);
		obj1.display();
		

	}

}
