package LoopingConcepts;

public class IfLoopExamples {

	public static void main(String[] args) {
		
		int x=50;
		int y=30;
		if(x<10 && y<20)//
		{
			System.out.println("Condition true");
		}
		
		System.out.println("Exiting from the code");
		

	}

}
