package LoopingConcepts;

public class NestedForLoopExamples {

	public static void main(String[] args) {
		
		for(int i=0;i<5;i++)///i=0,0<5/i=1,1<5
		{
			for(int j=0;j<5;j++)///
			{
				System.out.print(i+"  ");
				System.out.println(j);
				
			}
		}
		

	}

}
