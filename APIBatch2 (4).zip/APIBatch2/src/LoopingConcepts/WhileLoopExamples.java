package LoopingConcepts;

public class WhileLoopExamples {

	public static void main(String[] args) {
		
		int i=1;
		while(i<10)///1<3//2<3//3<3
		{
			System.out.println(i);//1//2
			i++;//1++//2++
		}
		

	}

}
