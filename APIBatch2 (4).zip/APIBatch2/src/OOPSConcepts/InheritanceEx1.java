package OOPSConcepts;

class A4
{
	void display()
	{
		System.out.println("I am display method");
	}
}

class B4 extends A4
{
	void test()
	{
		System.out.println("I am test method");
	}
}


class C4 extends B4
{
	void message()
	{
		System.out.println("I am message method");
	}
}

public class InheritanceEx1 {

	public static void main(String[] args) {
		
		C4 obj=new C4();
		obj.display();
		obj.test();
		obj.message();
		

	}

}
