package OOPSConcepts;

class Mammal
{
	void eat()
	{
		System.out.println("Mammals eat");
	}
}

class Dog extends Mammal
{
	void eat()
	{
		System.out.println("dogs eat");
	}
	
	void bark()
	{
		System.out.println("dogs bark");
	}
	
	void work()
	{
		eat();
		bark();
		super.eat();
	}
	
	
	
}

public class UsingSuperForMethods {

	public static void main(String[] args) {
		
		Dog obj=new Dog();
		obj.work();

	}

}
