package KeywordsInJava;

class Student8
{
	int roll;
	String name;
	String degree;
	float fees;
	
	Student8(int roll,String name,String degree)
	{
		this.roll=roll;
		this.name=name;
		this.degree=degree;
		
	}
	
	Student8(int roll,String name,String degree,float fees)
	{
		this(roll,name,degree);//reusing constructor
		this.fees=fees;
		
	}
	
	
}




public class RealUsageofThis {

	public static void main(String[] args) {
		

	}

}
