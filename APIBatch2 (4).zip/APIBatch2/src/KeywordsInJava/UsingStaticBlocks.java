package KeywordsInJava;

public class UsingStaticBlocks {
	
	static
	{
		System.out.println("I am static block");
	}
	
	

	public static void main(String[] args) {
		
		
		System.out.println("Hello");
		
		
		
		

	}

}
