package KeywordsInJava;

class Employee
{
	int empid;
	String name;
	static String CompName="Infosys";
	
	Employee(int e,String n)
	{
		empid=e;
		name=n;
	}
	
	
	void display()
	{
		System.out.println(empid);
		System.out.println(name);
		System.out.println(CompName);
		
	}
	
}


public class StaticVariables {

	public static void main(String[] args) {
		
		Employee obj=new Employee(1234,"Tom");
		Employee obj1=new Employee(6234,"Mark");
		obj.display();
		obj1.display();
		
		
		
		

	}

}
