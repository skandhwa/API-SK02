package KeywordsInJava;

class A6
{
	String name;
	int id;
	float salary;
	
	A6(String name,int id,float salary)
	{
		this.name=name;
		this.id=id;
		this.salary=salary;
	}
	
	void display()
	{
		System.out.println(name+" "+id+" "+salary);
	}
	
	
}

public class UsingThisKeyword {

	public static void main(String[] args) {
		
		A6 obj=new A6("Monty",1234,75000f);
		obj.display();
		

	}

}
