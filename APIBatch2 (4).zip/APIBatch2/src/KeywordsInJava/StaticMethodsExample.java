package KeywordsInJava;

class D2
{
	static void display()
	{
		System.out.println("Hello");
	}
	
}


public class StaticMethodsExample {

	public static void main(String[] args) {
		
		D2.display();
		
		
		

	}

}
