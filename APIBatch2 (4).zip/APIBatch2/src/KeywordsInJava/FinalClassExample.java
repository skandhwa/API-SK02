package KeywordsInJava;


final class A9
{
	void display()
	{
		System.out.println("Hello");
	}
}


class D9 extends A9
{
	void display1()
	{
		System.out.println("Hello all");
	}
}


public class FinalClassExample {

	public static void main(String[] args) {
		
		D9 obj=new D9();
		obj.display();
		obj.display1();
		

	}

}
