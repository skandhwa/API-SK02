package MyPractice;

public class UnaryOperators {

	public static void main(String[] args) {
		
//		int a=5;
//		int b=10;
//		int c=7;
		
//		int b=a--;
//		System.out.println(b);				
//		int c=a++ + ++b + ++a - --b;	
//		System.out.println(c);
		
		/// 20 + 11 + (++21) - (--11)
		
		// 20+11+22-10
		
	//int c= ++a + a++ - b-- + ++b;
	
	/// 6+6-10 + (++9)
	//6+6-10+10
	
	//System.out.println(c);//13//12//
		int a=5;
		int b=10;
		int c=7;
	
	int d= c++ + ++a + b++ - --c + ++b;
	
	///  7 + 6 + 10 - (--8) + (++11)
	//   7+6+10-7+12
	System.out.println(d);
		
		
		

	}

}
