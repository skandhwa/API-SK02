package MyPractice;

public class MethodExample1 {
	
	void display()
	{
		System.out.println("Hello");
	}
	
	void test()
	{
		System.out.println("I am a test method");
	}
	
	

	public static void main(String[] args) {
		
		
		MethodExample1 obj=new MethodExample1();
		obj.display();
		obj.test();
		
		
		

	}

}
