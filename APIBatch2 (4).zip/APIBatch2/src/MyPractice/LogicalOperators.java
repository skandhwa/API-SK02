package MyPractice;

public class LogicalOperators {

	public static void main(String[] args) {
		
		int x=20;
		int y=30;
		int z=15;
		
		if(x<y || z>y || z>x)
		{
			System.out.println("true");
		}
		
		else
		{
			System.out.println("false");
		}
		
		

	}

}
