package MyPractice;

public class LargestbwtwoNumber {

	public static void main(String[] args) {
		
		int a=200;
		int b=300;
		int c=25;
		
//		if(a>b)
//		{
//			System.out.println("a is maximum");
//		}
//		else
//		{
//			System.out.println("b is maximum");
//		}
		
//	int min=	(a<b) ? a:b;
//	System.out.println(min);
		
		
		int max= (a>b)?(a>c?a:c) :(b>c?b:c);
		
		System.out.println(max);
		

	}

}
