package MyPractice;

public class RelationalOperator {

	public static void main(String[] args) {
		
		int x=10;//initialization
		int y=20;
		
		if(x==y/2)//10==10
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
		

	}

}
