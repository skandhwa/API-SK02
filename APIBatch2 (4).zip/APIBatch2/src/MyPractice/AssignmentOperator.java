package MyPractice;

public class AssignmentOperator {

	public static void main(String[] args) {
		
//		int a=400;
//		a/=12; //a=a/12
//		
//		System.out.println(a);
		
		int b=9;
		int a=1;
		
		System.out.println(a&b);
		
		

	}

}
