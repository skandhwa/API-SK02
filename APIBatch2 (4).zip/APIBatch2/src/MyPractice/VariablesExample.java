package MyPractice;

public class VariablesExample {
	
	int k=20;
	
	int sum()
	{
		int x=20;
		int y=30;
		int q=k+40;
		
		
		 return x+y;
		 
		
		 
		 
		
	}
	
	
	void message()
	{
		int p=k+30;
	}
	
	
	

	public static void main(String[] args) {
		

	}

}
