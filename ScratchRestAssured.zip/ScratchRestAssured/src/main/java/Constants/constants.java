package Constants;

public class constants {
	
	public static final String ExcelPath="src\\test\\java\\TestData\\TestData3rdJune.xlsx";
	//public static final String ExcelPath_UpdateUser="D:\\TestData3rdJune.xlsx";
	public static final String sheetName="Sheet1";

}
