package MyPractice;

class C
{
	int i;
	float j;
	long k;
	
	
	C()
	{
		
	}
	
	
//	 C()
//	{
//		System.out.println("I am constructor");
//	}
	
	
	void display()
	{
		System.out.println(i+" "+j+" "+k);
	}
}


public class ConstructorExample {

	public static void main(String[] args) {
	
		C obj=new C();
		obj.display();
		

	}

}
