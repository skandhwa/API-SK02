package MyPractice;

public class LogicalNotOperator {

	public static void main(String[] args) {
		
		int x=10;
		int y=20/2;
		
		if(x!=y)//10!=10
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
		
		

	}

}
