package MyPractice;

class B
{
	void test(int x,int y,int z)
	{
		int sum=x+y+z;
		System.out.println(sum);
	}
	
	
	float message(float a,int b,int c)
	{
		return a*b*c;
	}
	}



public class ParametrizedMethods {
	
	double display(double x,double y)
	{
		double z=x/y;
		//System.out.println(z);
		
		return z;
		
		
	}

	public static void main(String[] args) {
		
		B obj=new B();
		obj.test(23,45,54);
	System.out.println(obj.message(23.66f, 54, 32));	
		
	ParametrizedMethods obj1=new ParametrizedMethods();
System.out.println(obj1.display(230, 2));	
		
		

	}

}
