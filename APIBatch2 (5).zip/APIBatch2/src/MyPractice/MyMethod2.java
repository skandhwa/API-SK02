package MyPractice;
class A
{
	void test()
	{
		System.out.println("Hello");
	}
	
	int sum()
	{
		int a=10;
		int b=20;
		int c=a+b;
		return c;
	}
	
	float multiply()
	{
		int x=20;
		int y=30;
		int z=x*y;
		return z;		
	}
	}
public class MyMethod2 {

	public static void main(String[] args) 
	{
		A abcd=new A();
		abcd.test();
	System.out.println(abcd.sum());	
	
	System.out.println(abcd.multiply());
			}

}
