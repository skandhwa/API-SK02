package MyPractice;

import java.util.Scanner;

public class TakingInputFromUser {

	public static void main(String[] args) {
		
//		float num1,num2,sum;
		Scanner sc=new Scanner(System.in);
//		
//		System.out.println("Enter the first number");
//		
//		num1=sc.nextFloat();
//		System.out.println("Enter the second number");
//		
//		num2=sc.nextInt();
//		
//	   sum=num1+num2;
//	   System.out.println("The result is  "+sum);
	   
	   System.out.println("Enter the name");
	   String name;
	   name=sc.nextLine();
	   int x=name.length();
	   System.out.println(x);
	   
	   
	   System.out.println("Enter the character");
	   char ch;
	   ch=sc.nextLine().charAt(0);
	   
	   
	   
	   
	  
	   
		
		
		

	}

}
