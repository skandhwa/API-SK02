package MyPractice;

public class DataTypesExample {

	public static void main(String[] args) {
		
		boolean flag=false;
		
		byte x=122;
		
		short y=3297;///1000 to 2000//2000 to 4000
		
		int p=6000;
		
		int k=2147483647;
		
		long h=320940329032312328l;
		
		float t=21232131232327487321321.1231223432434323f;
		double n=2713721357123571253721537215321357213512.2153721573523521;
		char ch='1';
		System.out.println(ch);
		

	}

}
