package OOPSConcepts;

class Bank
{
	 int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
	
//	void test()
//	{
//		getROI(5,7);
//		super.getROI(0, 0);
//	}
	
	
}


class Bandhan extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

public class MethodOverriding {

	public static void main(String[] args) {
		
		
		Bandhan obj=new Bandhan();
	System.out.println(obj.getROI(3,4));	
	
	
	SBI obj1=new SBI();
	System.out.println(obj1.getROI(7,4));	
	

	}

}
