package OOPSConcepts;

class Animal5
{
	String colour="white";
}

class TestNew6 extends Animal5
{
	
		String colour="violet";
		
	
}

class Dog5 extends TestNew6
{
	String colour="black";
	
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
		
	}
	}

public class SuperKeywordExample {

	public static void main(String[] args) {
		
		Dog5 obj=new Dog5();
		obj.display();
		
		
		
		

	}

}
