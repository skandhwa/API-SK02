package OOPSConcepts;


class D3
{
	static int sum(int a,int b)
	{
		return a+b;
	}
	
	static float sum(float x,float y,float z)
	{
		return x+y+z;
	}
}

public class MethodOverloadingEx {

	public static void main(String[] args) {
		
		//D3 obj=new D3();
	System.out.println(D3.sum(34, 99));	;
	System.out.println	(D3.sum(34.78f, 99.877f,76.554f));
		
		
		

	}

}
