package OOPSConcepts;

class Emp2
{
	int id;
	String name;
	
	Emp2(int i,String n)
	{
		id=i;
		name=n;
	}
	
	
	
}

class Person extends Emp2
{
	float salary;
	Person(int i,String n,float s)
	{
		
		super(i,n);
		salary=s;
		
	}
	
	void display()
	{
		System.out.println(id);
		System.out.println(name);
		System.out.println(salary);
	}
}




public class RealUsageofSuper {

	public static void main(String[] args) {
		
		
		Person obj=new Person(1234,"saurabh",5000.0f);
		obj.display();
		

	}

}
