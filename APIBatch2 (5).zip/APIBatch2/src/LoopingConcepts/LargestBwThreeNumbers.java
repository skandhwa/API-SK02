package LoopingConcepts;

public class LargestBwThreeNumbers {

	public static void main(String[] args) {
		
		int a=200;
		int b=30;
		int c=40;
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("a is largest");
			}
			else
			{
				System.out.println("c is largest");
			}
		}
		
		else
		{
			if(b>c)
			{
				System.out.println("b is largest");
			}
			else
			{
				System.out.println("c is largest");
			}
		}
		
		

	}

}
