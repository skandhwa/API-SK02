package LoopingConcepts;

public class ifElseLoopEx {

	public static void main(String[] args) {
		
		int x=200;
		int y=30;
		
//		if(x%2==0)
//		{
//			System.out.println("Even Number");
//		}
//		
//		else
//		{
//			System.out.println("odd number");
//		}
//		
		
		
		if(x>y)
		{
			System.out.println("x is largest");
		}
		else
		{
			System.out.println("y is largest");
		}
		
		
		

	}

}
