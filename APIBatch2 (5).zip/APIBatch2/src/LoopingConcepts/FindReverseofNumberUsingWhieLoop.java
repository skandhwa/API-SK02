package LoopingConcepts;

public class FindReverseofNumberUsingWhieLoop {

	public static void main(String[] args) {
		
		int num=7456;
		int rev=0;
		int rem;
		while(num!=0)//456!=0///45!=0///4!=0//0!=0
		{
			rem=num%10;///rem=456%10=6  /// rem=45%10=5 ///rem=4%10=4
			rev=rev*10+rem;///rev=0+6=6  // rev= 6*10+5=65// rev=65*10+4=654
			num=num/10;//456/10=45    // 45/10=4 ///4/10=0
			
			
			
		}
		
		System.out.println(rev);
		
		
		

	}

}
