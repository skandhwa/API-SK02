package LoopingConcepts;

public class NestedIfLoop {

	public static void main(String[] args) {
		
		int age=28;
		int poll=2;
		String citizen="Indian";
		
		if(age>18)//28>18
		{
			if(poll==1)///2==1
			{
				
				
				if(citizen=="Indian")
				{
					System.out.println("You are elligible to vote");
				}
			}
			
			
		}
		
		System.out.println("Exiting from the code");

		
		

	}

}
