package ArrayExamples;

public class LargestOrSmallestNumberinArray {
	
	//public  static int getThirdLargest(int []a,int total)
	
	public  static int getFourthSmallest(int []a,int total)
	{
		
		
		for(int i=0;i<total;i++)//i=0,0<4//i=1,1<4//i=2,2<4
		{
			for(int j=i+1;j<total;j++)
			{
				if(a[i]>a[j])//a[1]>a[3]
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
				}
			}
		}
		return a[5-1];///return a[9-3]=a[6]
		
	}
	
	public static void main(String[] args) {
		
		int []a= {23,65,12,45,678,145,7,1,35};
	System.out.println(getFourthSmallest(a,9));	
		
		
		
	

	}

}
