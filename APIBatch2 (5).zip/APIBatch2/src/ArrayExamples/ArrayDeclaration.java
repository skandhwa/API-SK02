package ArrayExamples;

public class ArrayDeclaration {

	public static void main(String[] args) {
		
		int []a=new int[5];
		
		
		int []b= {23,12,34,56,78};
		
		a[0]=5;
		a[1]=7;
		a[2]=9;
		a[3]=14;
		a[4]=16;
		//a[5]=21;
		
	int x=	a.length;
	System.out.println("The length of array is "+x);
	
	for(int i=0;i<x;i++)//i=0,0<5//i=1,1<5//5<5
	{
		System.out.println(a[i]);//a[0]//a[1]//a[2]//a[3]...
	}
	
		
		

	}

}
