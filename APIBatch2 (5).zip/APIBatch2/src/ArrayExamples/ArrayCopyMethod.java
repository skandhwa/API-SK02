package ArrayExamples;

public class ArrayCopyMethod {

	public static void main(String[] args) {
		
        int a[]= {12,34,56,68,98};
        
        int sum=0;
        
        for(int i=0;i<a.length;i++)
        {
        	sum=sum+a[i];
        }
        
        System.out.println("The sum is "+sum);
        
        
		
//		int []b=new int[a.length];
//		
//		for(int i=0;i<a.length;i++)
//		{
//			b[i]=a[i];
//		}
//		
//		System.out.println("Elements of new array are");
//		
//		for(int i=0;i<a.length;i++)
//		{
//			System.out.print(b[i]+" ");
//		}
		
		
		
		
		
		

	}

}
