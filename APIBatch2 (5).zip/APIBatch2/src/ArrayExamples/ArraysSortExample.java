package ArrayExamples;

public class ArraysSortExample {

	public static void main(String[] args) {
		
		int a[]= {23,65,12,45,678,145,7,1,35};
		int temp;
		
		for(int i=0;i<a.length;i++)//i=0,0<4//i=1,1<4//i=2,2<4
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])//a[1]>a[3]
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
				}
			}
			
			System.out.println(a[i]);
		}
		
		
		
		

	}

}
