package ArrayExamples;

public class MethodsinArray {

	public static void main(String[] args) {
		
		int a[]= {12,34,56,68,98};
		
		int []b=new int[5];
		
		b=a;
		
		System.out.println(b);
		
		

	}

}
