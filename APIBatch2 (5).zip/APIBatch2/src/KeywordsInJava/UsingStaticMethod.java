package KeywordsInJava;

class Cube
{
	static int volume(int x)
	{
		return x*x*x;
	}
}

public class UsingStaticMethod {
public static void main(String[] args) {
	
	System.out.println(Cube.volume(5));
	
	
	
		

	}

}
