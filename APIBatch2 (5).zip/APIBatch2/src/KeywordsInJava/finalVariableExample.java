package KeywordsInJava;

class C6
{
	final int speed=40;
	
	void display()
	{
		speed=60;
		System.out.println(speed);
	}
}



public class finalVariableExample {

	public static void main(String[] args) {
		
		
		C6 obj=new C6();
		obj.display();
		

	}

}
